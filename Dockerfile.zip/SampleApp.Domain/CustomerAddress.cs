﻿namespace SampleApp.Domain;

public class CustomerAddress
{
    public long CustomersId { get; set; }
    public long AddressId { get; set; }
}