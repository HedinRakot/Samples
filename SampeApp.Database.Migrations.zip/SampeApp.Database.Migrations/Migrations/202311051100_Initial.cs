﻿using FluentMigrator;

namespace SampeApp.Database.Migrations.Migrations;

[Migration(202311051100, "Initial")]
public class Initial : AutoReversingMigration
{
    public override void Up()
    {
        
    }
}
